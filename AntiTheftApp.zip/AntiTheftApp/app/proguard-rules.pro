# Règles ProGuard/R8.
# minifyEnabled est à false en release par défaut, donc rien n'est requis ici.
# Ajoute tes règles -keep si tu actives la minification.
