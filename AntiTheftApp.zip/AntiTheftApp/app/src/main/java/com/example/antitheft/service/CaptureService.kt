package com.example.antitheft.service

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.example.antitheft.R
import com.example.antitheft.util.LocationFetcher
import com.example.antitheft.util.Mailer
import java.io.File
import java.util.concurrent.Executors

/**
 * Service en avant-plan (type "camera|location") qui :
 *  1) prend une photo en silence avec la caméra frontale (CameraX, sans aperçu),
 *  2) récupère la localisation,
 *  3) envoie le tout par e-mail,
 *  puis s'arrête.
 *
 * ⚠️ Limite Android 11+ : démarrer un service caméra depuis l'arrière-plan (ce qui est
 *    le cas lors d'un changement de SIM) peut être bloqué par le système. Pour maximiser
 *    les chances : accorder la permission caméra ET exclure l'appli des optimisations
 *    batterie. À tester sur l'appareil cible.
 *
 * LifecycleService est un Service qui est aussi LifecycleOwner : indispensable à CameraX.
 */
class CaptureService : LifecycleService() {

    private val bgExecutor = Executors.newSingleThreadExecutor()

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        val reason = intent?.getStringExtra(EXTRA_REASON) ?: "Alerte antivol"
        capturePhoto(reason)
        return START_NOT_STICKY
    }

    private fun capturePhoto(reason: String) {
        val hasCamera = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasCamera) {
            sendReport(reason, null)
            return
        }

        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()

                provider.unbindAll()
                // Caméra frontale pour photographier la personne ; sinon, caméra arrière.
                val selector =
                    if (provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA))
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    else
                        CameraSelector.DEFAULT_BACK_CAMERA

                provider.bindToLifecycle(this, selector, imageCapture)

                val photo = File(cacheDir, "capture_${System.currentTimeMillis()}.jpg")
                val options = ImageCapture.OutputFileOptions.Builder(photo).build()

                imageCapture.takePicture(
                    options,
                    bgExecutor,
                    object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(results: ImageCapture.OutputFileResults) {
                            sendReport(reason, photo)
                        }

                        override fun onError(exc: ImageCaptureException) {
                            sendReport(reason, null)
                        }
                    }
                )
            } catch (e: Exception) {
                sendReport(reason, null)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /** Récupère la localisation puis envoie l'e-mail (avec ou sans photo), puis s'arrête. */
    private fun sendReport(reason: String, photo: File?) {
        LocationFetcher.getQuickLocation(this) { mapsLink ->
            bgExecutor.execute {
                val location = mapsLink ?: "indisponible"
                val photoNote = if (photo == null) " (photo indisponible)" else ""
                Mailer.send(
                    this,
                    subject = "[AntiTheft] $reason",
                    body = "$reason$photoNote\n\nLocalisation : $location",
                    attachment = photo
                )
                photo?.delete()
                stopForegroundCompat()
                stopSelf()
            }
        }
    }

    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION") stopForeground(true)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            mgr.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Capture antivol",
                    NotificationManager.IMPORTANCE_MIN
                )
            )
        }
    }

    private fun buildNotification() =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Vérification de sécurité")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .build()

    companion object {
        const val CHANNEL_ID = "antitheft_capture_channel"
        const val NOTIF_ID = 1002
        const val EXTRA_REASON = "extra_reason"
    }
}
