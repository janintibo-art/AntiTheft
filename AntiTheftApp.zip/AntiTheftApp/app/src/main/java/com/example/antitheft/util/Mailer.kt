package com.example.antitheft.util

import android.content.Context
import android.util.Log
import java.io.File
import java.util.Properties
import javax.mail.Authenticator
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart

/**
 * Envoie un e-mail via SMTP (STARTTLS) avec une éventuelle pièce jointe.
 *
 * ⚠️ À appeler depuis un thread d'arrière-plan (jamais le thread principal).
 * ⚠️ Le mot de passe doit être un « mot de passe d'application » (Gmail : compte
 *    avec validation en 2 étapes → myaccount.google.com → Sécurité → Mots de passe
 *    des applications). Le mot de passe normal du compte ne fonctionnera pas.
 */
object Mailer {

    private const val TAG = "Mailer"

    fun send(ctx: Context, subject: String, body: String, attachment: File?): Boolean {
        val sender = Prefs.getSenderEmail(ctx)
        val password = Prefs.getSenderPassword(ctx)
        val recipient = Prefs.getRecipientEmail(ctx)

        if (sender.isNullOrBlank() || password.isNullOrBlank() || recipient.isNullOrBlank()) {
            Log.w(TAG, "Configuration e-mail incomplète, envoi ignoré.")
            return false
        }

        val props = Properties().apply {
            put("mail.smtp.auth", "true")
            put("mail.smtp.starttls.enable", "true")
            put("mail.smtp.host", Prefs.getSmtpHost(ctx))
            put("mail.smtp.port", Prefs.getSmtpPort(ctx).toString())
        }

        val session = Session.getInstance(props, object : Authenticator() {
            override fun getPasswordAuthentication() =
                PasswordAuthentication(sender, password)
        })

        return try {
            val message = MimeMessage(session).apply {
                setFrom(InternetAddress(sender))
                setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient))
                setSubject(subject)
            }

            val multipart = MimeMultipart()
            multipart.addBodyPart(MimeBodyPart().apply { setText(body) })

            if (attachment != null && attachment.exists()) {
                multipart.addBodyPart(MimeBodyPart().apply { attachFile(attachment) })
            }

            message.setContent(multipart)
            Transport.send(message)
            Log.i(TAG, "E-mail envoyé à $recipient")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Échec de l'envoi de l'e-mail", e)
            false
        }
    }
}
