package com.example.antitheft.util

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Chiffrement local des valeurs sensibles via l'Android Keystore.
 *
 * La clé AES-256-GCM est générée et conservée dans le composant sécurisé du téléphone
 * (matériel quand disponible) : elle n'est jamais exportable ni lisible par l'application.
 * C'est l'approche recommandée depuis la dépréciation d'EncryptedSharedPreferences (2025),
 * et elle n'ajoute aucune dépendance (tout vient du framework Android).
 *
 * Format produit : "v1:" + base64(iv) + ":" + base64(ciphertext).
 * Une chaîne sans préfixe "v1:" est traitée comme du texte en clair — ce qui assure :
 *   - la compatibilité avec d'anciennes valeurs enregistrées avant le chiffrement,
 *   - un repli si le Keystore échoue (rare, sur certains OEM).
 *
 * Remarque : l'appli a android:allowBackup="false", donc ces valeurs ne sont pas
 * sauvegardées par Auto Backup (une restauration échouerait, la clé n'existant plus).
 */
object Crypto {

    private const val TAG = "Crypto"
    private const val KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "antitheft_master_key"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val PREFIX = "v1:"
    private const val GCM_TAG_BITS = 128

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    fun encrypt(plain: String): String {
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val iv = cipher.iv
            val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
            PREFIX + b64(iv) + ":" + b64(ct)
        } catch (e: Exception) {
            Log.e(TAG, "Chiffrement impossible, stockage en clair (repli).", e)
            plain
        }
    }

    fun decrypt(stored: String): String {
        if (!stored.startsWith(PREFIX)) return stored // texte en clair / ancienne valeur
        return try {
            val parts = stored.removePrefix(PREFIX).split(":")
            val iv = unb64(parts[0])
            val ct = unb64(parts[1])
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(
                Cipher.DECRYPT_MODE,
                getOrCreateKey(),
                GCMParameterSpec(GCM_TAG_BITS, iv)
            )
            String(cipher.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) {
            Log.e(TAG, "Déchiffrement impossible.", e)
            ""
        }
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)
}
