package com.example.antitheft.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices

/**
 * Récupère rapidement la dernière position connue sous forme de lien Google Maps.
 * Renvoie null si indisponible (permission refusée ou aucune position en cache).
 */
object LocationFetcher {

    @SuppressLint("MissingPermission")
    fun getQuickLocation(ctx: Context, callback: (String?) -> Unit) {
        val fine = ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!fine && !coarse) {
            callback(null)
            return
        }

        LocationServices.getFusedLocationProviderClient(ctx)
            .lastLocation
            .addOnSuccessListener { loc ->
                callback(loc?.let { "https://maps.google.com/?q=${it.latitude},${it.longitude}" })
            }
            .addOnFailureListener { callback(null) }
    }
}
