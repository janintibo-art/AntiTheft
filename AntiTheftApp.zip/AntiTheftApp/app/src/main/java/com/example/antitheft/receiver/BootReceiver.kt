package com.example.antitheft.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.antitheft.service.BatteryMonitorService
import com.example.antitheft.util.SimChecker

/**
 * Au redémarrage du téléphone :
 *  1) vérifie si la SIM a changé pendant que le téléphone était éteint,
 *  2) relance la surveillance batterie.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            SimChecker.checkSimChange(context)
            ContextCompat.startForegroundService(
                context,
                Intent(context, BatteryMonitorService::class.java)
            )
        }
    }
}
