package com.example.antitheft.util

import android.content.Context

/**
 * Stockage des réglages.
 *
 * Les deux secrets — le code de désinstallation (PIN) et le mot de passe d'application
 * e-mail — sont chiffrés via [Crypto] (Android Keystore) avant d'être écrits.
 * Les autres champs (numéros, e-mails, seuil) restent en clair.
 *
 * Migration transparente : une valeur enregistrée en clair par une ancienne version est
 * relue normalement, puis ré-écrite chiffrée au prochain enregistrement.
 */
object Prefs {
    private const val FILE = "antitheft_prefs"

    private const val KEY_CONTACT = "trusted_contact"
    private const val KEY_PIN = "uninstall_pin"
    private const val KEY_SIM_FP = "sim_fingerprint"
    private const val KEY_LOW_BATT_SENT = "low_batt_sent"
    private const val KEY_THRESHOLD = "batt_threshold"

    private const val KEY_RECIPIENT = "recipient_email"
    private const val KEY_SENDER = "sender_email"
    private const val KEY_SENDER_PWD = "sender_password"
    private const val KEY_SMTP_HOST = "smtp_host"
    private const val KEY_SMTP_PORT = "smtp_port"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // --- Contact SMS ---
    fun setContact(ctx: Context, number: String) =
        prefs(ctx).edit().putString(KEY_CONTACT, number).apply()
    fun getContact(ctx: Context): String? =
        prefs(ctx).getString(KEY_CONTACT, null)

    // --- Code de désinstallation (CHIFFRÉ) ---
    fun setPin(ctx: Context, pin: String) =
        prefs(ctx).edit().putString(KEY_PIN, Crypto.encrypt(pin)).apply()
    fun getPin(ctx: Context): String? =
        prefs(ctx).getString(KEY_PIN, null)?.let { Crypto.decrypt(it) }

    // --- Empreinte de la SIM ---
    fun setSimFingerprint(ctx: Context, fp: String?) =
        prefs(ctx).edit().putString(KEY_SIM_FP, fp).apply()
    fun getSimFingerprint(ctx: Context): String? =
        prefs(ctx).getString(KEY_SIM_FP, null)

    // --- Drapeau batterie faible ---
    fun setLowBattSent(ctx: Context, sent: Boolean) =
        prefs(ctx).edit().putBoolean(KEY_LOW_BATT_SENT, sent).apply()
    fun wasLowBattSent(ctx: Context): Boolean =
        prefs(ctx).getBoolean(KEY_LOW_BATT_SENT, false)

    // --- Seuil batterie ---
    fun setThreshold(ctx: Context, pct: Int) =
        prefs(ctx).edit().putInt(KEY_THRESHOLD, pct).apply()
    fun getThreshold(ctx: Context): Int =
        prefs(ctx).getInt(KEY_THRESHOLD, 5)

    // --- E-mail ---
    fun setRecipientEmail(ctx: Context, v: String) =
        prefs(ctx).edit().putString(KEY_RECIPIENT, v).apply()
    fun getRecipientEmail(ctx: Context): String? =
        prefs(ctx).getString(KEY_RECIPIENT, null)

    fun setSenderEmail(ctx: Context, v: String) =
        prefs(ctx).edit().putString(KEY_SENDER, v).apply()
    fun getSenderEmail(ctx: Context): String? =
        prefs(ctx).getString(KEY_SENDER, null)

    // Mot de passe d'application (CHIFFRÉ)
    fun setSenderPassword(ctx: Context, v: String) =
        prefs(ctx).edit().putString(KEY_SENDER_PWD, Crypto.encrypt(v)).apply()
    fun getSenderPassword(ctx: Context): String? =
        prefs(ctx).getString(KEY_SENDER_PWD, null)?.let { Crypto.decrypt(it) }

    // Défauts Gmail. Change-les pour un autre fournisseur (Outlook : smtp.office365.com, etc.)
    fun getSmtpHost(ctx: Context): String =
        prefs(ctx).getString(KEY_SMTP_HOST, "smtp.gmail.com") ?: "smtp.gmail.com"
    fun getSmtpPort(ctx: Context): Int =
        prefs(ctx).getInt(KEY_SMTP_PORT, 587)
}
