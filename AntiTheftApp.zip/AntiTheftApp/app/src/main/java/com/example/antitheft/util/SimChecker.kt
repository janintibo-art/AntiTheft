package com.example.antitheft.util

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import com.example.antitheft.service.CaptureService

object SimChecker {

    /**
     * Compare la SIM actuelle à celle mémorisée et, en cas de changement :
     *  - envoie un SMS de localisation au contact de confiance,
     *  - déclenche CaptureService (photo frontale + localisation par e-mail).
     *
     * Empreinte utilisée :
     *  - Android 9 et antérieur : ICCID (numéro de série, fiable).
     *  - Android 10+ : getSimSerialNumber() est bloqué pour les apps tierces, donc on
     *    construit une empreinte à partir de l'opérateur (carrierId + pays + slot).
     *    ⚠️ Conséquence : changer pour une SIM du MÊME opérateur peut ne pas être détecté.
     */
    fun checkSimChange(ctx: Context) {
        val current = readSimFingerprint(ctx)
        val stored = Prefs.getSimFingerprint(ctx)

        when {
            // Premier enregistrement : on mémorise la SIM légitime, sans alerter.
            stored == null && current != null ->
                Prefs.setSimFingerprint(ctx, current)

            // SIM différente détectée.
            current != null && current != stored -> {
                Prefs.setSimFingerprint(ctx, current)
                onSimChanged(ctx)
            }

            else -> { /* SIM identique, ou empreinte illisible : rien à faire */ }
        }
    }

    /** Fixe l'empreinte de référence si elle n'existe pas encore (appelé depuis l'UI). */
    fun initBaselineIfNeeded(ctx: Context) {
        if (Prefs.getSimFingerprint(ctx) == null) {
            readSimFingerprint(ctx)?.let { Prefs.setSimFingerprint(ctx, it) }
        }
    }

    private fun onSimChanged(ctx: Context) {
        // 1) SMS de localisation (comme avant)
        AlertHelper.sendLocationAlert(ctx, "ALERTE antivol : la carte SIM a changé. Position :")

        // 2) Photo frontale + localisation par e-mail
        val intent = Intent(ctx, CaptureService::class.java)
            .putExtra(CaptureService.EXTRA_REASON, "Changement de carte SIM détecté")
        ContextCompat.startForegroundService(ctx, intent)
    }

    private fun readSimFingerprint(ctx: Context): String? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED
        ) return null

        return try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                val tm = ctx.getSystemService(TelephonyManager::class.java)
                @Suppress("DEPRECATION", "HardwareIds")
                tm.simSerialNumber
            } else {
                val sm = ctx.getSystemService(SubscriptionManager::class.java)
                val subs = sm.activeSubscriptionInfoList
                if (subs.isNullOrEmpty()) null
                else subs.sortedBy { it.simSlotIndex }.joinToString("|") { info ->
                    "${info.simSlotIndex}:${info.carrierId}:${info.countryIso}"
                }
            }
        } catch (e: SecurityException) {
            null
        }
    }
}
