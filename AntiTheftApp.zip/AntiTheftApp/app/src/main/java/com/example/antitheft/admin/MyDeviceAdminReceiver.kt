package com.example.antitheft.admin

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * Tant que l'administrateur est actif, l'application ne peut pas être désinstallée
 * directement : il faut d'abord le désactiver dans les réglages.
 *
 * NB : pour EXIGER un code au moment de la désactivation, Device Admin seul ne suffit
 * pas — il faut ajouter un AccessibilityService (voir README, « Pistes d'amélioration »).
 */
class MyDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return "Désactiver cette protection rendra l'application désinstallable. " +
            "Un code est requis dans l'application pour la retirer."
    }

    override fun onEnabled(context: Context, intent: Intent) {
        Toast.makeText(context, "Protection antivol activée", Toast.LENGTH_SHORT).show()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        Toast.makeText(context, "Protection désactivée", Toast.LENGTH_SHORT).show()
    }
}
