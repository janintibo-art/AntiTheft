package com.example.antitheft

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.antitheft.admin.MyDeviceAdminReceiver
import com.example.antitheft.service.BatteryMonitorService
import com.example.antitheft.util.Prefs
import com.example.antitheft.util.SimChecker

/**
 * UI construite en code (pas de layout XML) pour rester simple.
 * Tu peux la remplacer par un layout/Compose plus tard.
 */
class MainActivity : AppCompatActivity() {

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    private val bgLocationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val contact = field("Numéro de confiance (ex : +33612345678)",
            Prefs.getContact(this))
        val pin = field("Code de désinstallation", Prefs.getPin(this))
        val threshold = field("Seuil batterie % (ex : 5)",
            Prefs.getThreshold(this).toString())

        val recipient = field("E-mail destinataire (où recevoir la photo)",
            Prefs.getRecipientEmail(this))
        val senderEmail = field("E-mail expéditeur (compte Gmail d'envoi)",
            Prefs.getSenderEmail(this))
        val senderPwd = field("Mot de passe d'application", Prefs.getSenderPassword(this),
            password = true)

        val save = button("Enregistrer") {
            Prefs.setContact(this, contact.text.toString().trim())
            Prefs.setPin(this, pin.text.toString().trim())
            Prefs.setThreshold(this, threshold.text.toString().toIntOrNull() ?: 5)
            Prefs.setRecipientEmail(this, recipient.text.toString().trim())
            Prefs.setSenderEmail(this, senderEmail.text.toString().trim())
            Prefs.setSenderPassword(this, senderPwd.text.toString().trim())
            toast("Enregistré")
        }

        val perms = button("Demander les permissions") { requestPerms() }
        val admin = button("Activer la protection désinstallation") { enableAdmin() }
        val start = button("Démarrer la surveillance") {
            ContextCompat.startForegroundService(
                this, Intent(this, BatteryMonitorService::class.java)
            )
            SimChecker.initBaselineIfNeeded(this)
            toast("Surveillance démarrée")
        }

        val note = TextView(this).apply {
            text = "Astuce : le mot de passe d'application Gmail s'obtient sur " +
                "myaccount.google.com (validation en 2 étapes requise). " +
                "Pense aussi à exclure l'appli des optimisations batterie."
            setPadding(0, 24, 0, 0)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
            addView(contact); addView(pin); addView(threshold)
            addView(recipient); addView(senderEmail); addView(senderPwd)
            addView(save); addView(perms); addView(admin); addView(start)
            addView(note)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        // Tente de fixer l'empreinte SIM de référence dès l'ouverture (si permission OK).
        SimChecker.initBaselineIfNeeded(this)
    }

    private fun field(hintText: String, value: String?, password: Boolean = false) =
        EditText(this).apply {
            hint = hintText
            setText(value ?: "")
            if (password) inputType =
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

    private fun button(label: String, onClick: () -> Unit) =
        Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

    private fun requestPerms() {
        val list = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            list.add(Manifest.permission.READ_PHONE_NUMBERS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            list.add(Manifest.permission.POST_NOTIFICATIONS)

        permLauncher.launch(list.toTypedArray())

        // Localisation en arrière-plan : à accorder SÉPARÉMENT, après la localisation
        // « précise ». Sur Android 11+, choisir « Toujours autoriser » dans les réglages.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            bgLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        }
    }

    private fun enableAdmin() {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val component = ComponentName(this, MyDeviceAdminReceiver::class.java)
        if (!dpm.isAdminActive(component)) {
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
                putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Empêche la désinstallation de l'application antivol sans le code."
                )
            }
            startActivity(intent)
        } else {
            toast("Déjà activé")
        }
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
