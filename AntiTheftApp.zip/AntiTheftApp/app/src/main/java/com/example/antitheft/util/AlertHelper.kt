package com.example.antitheft.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource

object AlertHelper {

    /** Envoie un SMS au contact de confiance (découpé si trop long). */
    fun sendSms(ctx: Context, message: String) {
        val number = Prefs.getContact(ctx)
        if (number.isNullOrBlank()) return
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val sms = smsManager(ctx)
        val parts = sms.divideMessage(message)
        sms.sendMultipartTextMessage(number, null, parts, null, null)
    }

    /**
     * Envoie une alerte avec la position.
     * 1) position de la dernière localisation connue → immédiate
     * 2) tentative de position fraîche → si elle arrive à temps
     */
    @SuppressLint("MissingPermission")
    fun sendLocationAlert(ctx: Context, prefix: String) {
        val fineGranted = ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!fineGranted) {
            sendSms(ctx, "$prefix (localisation indisponible : permission refusée)")
            return
        }

        val client = LocationServices.getFusedLocationProviderClient(ctx)

        client.lastLocation.addOnSuccessListener { last ->
            if (last != null) sendSms(ctx, "$prefix ${mapsLink(last)}")
            else sendSms(ctx, "$prefix (aucune position en cache, recherche en cours...)")
        }

        val cts = CancellationTokenSource()
        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
            .addOnSuccessListener { loc ->
                if (loc != null) sendSms(ctx, "Position actuelle : ${mapsLink(loc)}")
            }
    }

    private fun mapsLink(loc: Location): String =
        "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"

    private fun smsManager(ctx: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            ctx.getSystemService(SmsManager::class.java)
        else
            @Suppress("DEPRECATION") SmsManager.getDefault()
}
