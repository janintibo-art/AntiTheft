package com.example.antitheft.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.antitheft.util.SimChecker

/**
 * Réagit au changement d'état de la SIM (insertion/retrait).
 *
 * ⚠️ Ce broadcast n'est pas garanti sur toutes les versions/constructeurs Android,
 * et sur Android 10+ on ne peut pas lire le numéro de série de la nouvelle SIM.
 * Sert surtout de complément à la vérification au démarrage (BootReceiver).
 */
class SimChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        SimChecker.checkSimChange(context)
    }
}
